package pl.sda.shopapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
